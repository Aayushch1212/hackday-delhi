package com.example.mobile2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
