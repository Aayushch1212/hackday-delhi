#!/bin/bash
solana-keygen new --no-outfile --no-bip39-passphrase